import pygame
import math
import sys

# --- НАСТРОЙКИ ---
SCREEN_WIDTH = 1024
SCREEN_HEIGHT = 768
FPS = 60

MAP_SIZE = 10
TILE_SIZE = 64
MAP = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
]

FOV = math.pi / 3
HALF_FOV = FOV / 2
NUM_RAYS = 240
MAX_DEPTH = 1000
DELTA_ANGLE = FOV / NUM_RAYS
SCALE = SCREEN_WIDTH // NUM_RAYS

pygame.init()
pygame.mixer.init()

# --- ПЕРЕМЕННЫЕ НАСТРОЕК (Перенесены вверх, чтобы не было ошибок загрузки) ---
sound_volume = 0.5       # Громкость звука (от 0.0 до 1.0)
game_language = "RU"     # Язык: "RU" или "EN"
ui_color = (255, 0, 0)   # Цвет интерфейса (по умолчанию красный)
crosshair_type = 1       # Тип прицела: 1 - точка, 2 - крестик

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN)
pygame.display.set_caption("PyDoom: Extended Edition 1.1")
clock = pygame.time.Clock()

pygame.mouse.set_visible(False)
pygame.event.set_grab(True)

font = pygame.font.SysFont('Impact', 40)
small_font = pygame.font.SysFont('Impact', 24)

# Загрузка спрайтов
try:
    enemy_texture = pygame.image.load("killer.png").convert_alpha()
    gun_texture = pygame.image.load("gun.png").convert_alpha()
    gun_texture = pygame.transform.scale(gun_texture, (350, 350))
    
    # ЗАГРУЖАЕМ ВТОРОЙ СТВОЛ (Пулемет):
    gun2_texture = pygame.image.load("gun2.png").convert_alpha()
    gun2_texture = pygame.transform.scale(gun2_texture, (350, 350))
    
    shoot_sound = pygame.mixer.Sound("shot.wav")
    shoot_sound.set_volume(sound_volume) 

    # Аптечка
    medkit_texture = pygame.image.load("hill.png").convert_alpha()
    
except pygame.error as e:
    print(f"Ошибка загрузки файлов: {e}\nУбедись, что killer.png, gun.png, gun2.png, hill.png и shot.wav в папке!")
    pygame.quit()
    sys.exit()

# Текстура стен
wall_texture = pygame.Surface((TILE_SIZE, TILE_SIZE))
wall_texture.fill((50, 50, 55))
for i in range(0, TILE_SIZE, 16):
    pygame.draw.line(wall_texture, (25, 25, 30), (0, i), (TILE_SIZE, i), 2)
    pygame.draw.line(wall_texture, (25, 25, 30), (i, 0), (i, TILE_SIZE), 2)

# --- СОСТОЯНИЕ ИГРЫ ---
player_x, player_y = 5 * TILE_SIZE, 5 * TILE_SIZE
player_angle = 0
player_speed = 5
player_hp = 100
mouse_sensitivity = 0.002

current_wave = 1
current_weapon = 1      # 1 - дробовик, 2 - пулемет

medkit_spawned = False       # Появилась ли аптечка на карте
medkit_timer = 0             # Таймер в кадрах до появления аптечки
medkit_x, medkit_y = 3 * TILE_SIZE, 3 * TILE_SIZE # Координаты спавна аптечки (в 3-й клетке)

# --- СОСТОЯНИЕ МЕНЮ ---
game_state = "MENU"    # Может быть "MENU", "PLAYING", "SETTINGS"
menu_selection = 0     # Какая кнопка сейчас выбрана (0 - Играть, 1 - Настройки, 2 - Выйти)

# Для аптечки (hill.png)
medkit_spawned = False
medkit_timer = 0
medkit_x, medkit_y = 0, 0

# Спавним первого врага
enemy_x, enemy_y = 3 * TILE_SIZE, 3 * TILE_SIZE
enemy_max_hp = 100
enemy_hp = enemy_max_hp
enemy_base_speed = 2.5 
enemy_speed = enemy_base_speed
enemy_damage = 1       
enemy_alive = True

wave_timer = 0         
game_over = False

shooting = False
shoot_frame = 0
weapon_damage = 35     

running = True
while running:
    # --- СИСТЕМА СОБЫТИЙ (ФИКС ОТСТУПОВ И ЛОГИКИ) ---
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
        # УПРАВЛЕНИЕ ЕСЛИ МЫ В ГЛАВНОМ МЕНЮ
        if game_state == "MENU":
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP or event.key == pygame.K_w:
                    menu_selection = (menu_selection - 1) % 3
                if event.key == pygame.K_DOWN or event.key == pygame.K_s:
                    menu_selection = (menu_selection + 1) % 3
                if event.key == pygame.K_RETURN: # Нажали ENTER
                    if menu_selection == 0:
                        game_state = "PLAYING" # Запуск игры
                        pygame.mouse.get_rel() # Сбрасываем мышь перед стартом
                    elif menu_selection == 1:
                        game_state = "SETTINGS" # Переход в настройки (сделаем в следующем шаге)
                    elif menu_selection == 2:
                        running = False # Выход
                        
        # УПРАВЛЕНИЕ ВО ВРЕМЯ ИГРЫ
        elif game_state == "PLAYING":
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    game_state = "MENU" # Кнопка ESC возвращает в меню
                if event.key == pygame.K_1:
                    current_weapon = 1
                if event.key == pygame.K_2:
                    current_weapon = 2

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and not game_over:
                if current_weapon == 1 and not shooting:
                    shooting = True
                    shoot_frame = 0
                    try:
                        shoot_sound.play()
                    except:
                        pass

    # --- ЛОГИКА ИГРЫ (СТРЕЛЬБА, АПТЕЧКА, КАМЕРА, ДВИЖЕНИЕ) ---
    if game_state == "PLAYING" and not game_over:
        # 1. СТРЕЛЬБА ИЗ ПУЛЕМЕТА (ЗАЖИМ)
        mouse_buttons = pygame.mouse.get_pressed()
        if mouse_buttons[0]: # Если зажата левая кнопка мыши
            if current_weapon == 2: # ПУЛЕМЕТ
                if not shooting:
                    shooting = True
                    shoot_frame = 0
                    try:
                        shoot_sound.play()
                    except:
                        pass

        # 2. ТАЙМЕР АПТЕЧКИ
        if player_hp < 50 and not medkit_spawned:
            medkit_timer += 1
            if medkit_timer >= 300: # 5 секунд при 60 FPS
                medkit_spawned = True
                medkit_timer = 0
        elif player_hp >= 50 and not medkit_spawned:
            medkit_timer = 0

        # 3. ПОДБОР АПТЕЧКИ ИГРОКОМ
        if medkit_spawned:
            med_dx = medkit_x - player_x
            med_dy = medkit_y - player_y
            med_dist = math.sqrt(med_dx**2 + med_dy**2)
            if med_dist < 30: # Если наступил на неё
                player_hp = min(100, player_hp + 50) # Лечимся
                medkit_spawned = False
                try:
                    shoot_sound.play() # Временный звук подбора
                except:
                    pass

        # 4. КАМЕРА
        mouse_rel = pygame.mouse.get_rel()
        player_angle += mouse_rel[0] * mouse_sensitivity

        # 5. ДВИЖЕНИЕ ИГРОКА WASD
        keys = pygame.key.get_pressed()
        cos_a = math.cos(player_angle)
        sin_a = math.sin(player_angle)
        move_x, move_y = 0, 0
        
        if keys[pygame.K_w]: move_x += cos_a; move_y += sin_a
        if keys[pygame.K_s]: move_x -= cos_a; move_y -= sin_a
        if keys[pygame.K_a]: move_x += sin_a; move_y -= cos_a
        if keys[pygame.K_d]: move_x -= sin_a; move_y += cos_a

        dist = math.sqrt(move_x**2 + move_y**2)
        if dist > 0:
            move_x = (move_x / dist) * player_speed
            move_y = (move_y / dist) * player_speed

        new_x = player_x + move_x
        new_y = player_y + move_y
        if MAP[int(player_y // TILE_SIZE)][int(new_x // TILE_SIZE)] == 0: player_x = new_x
        if MAP[int(new_y // TILE_SIZE)][int(player_x // TILE_SIZE)] == 0: player_y = new_y

        # --- ИИ ВРАГА И СИСТЕМА ВОЛН ---
        if enemy_alive:
            edx = player_x - enemy_x
            edy = player_y - enemy_y
            enemy_dist = math.sqrt(edx**2 + edy**2)
            
            if enemy_dist > 25: 
                next_enemy_x = enemy_x + (edx / enemy_dist) * enemy_speed
                next_enemy_y = enemy_y + (edy / enemy_dist) * enemy_speed
                
                if MAP[int(enemy_y // TILE_SIZE)][int(next_enemy_x // TILE_SIZE)] == 0:
                    enemy_x = next_enemy_x
                if MAP[int(next_enemy_y // TILE_SIZE)][int(enemy_x // TILE_SIZE)] == 0:
                    enemy_y = next_enemy_y
            else:
                player_hp -= enemy_damage
                if player_hp <= 0:
                    player_hp = 0
                    game_over = True
        else:
            wave_timer += 1
            if wave_timer > 120: 
                current_wave += 1
                enemy_alive = True
                wave_timer = 0
                
                enemy_x, enemy_y = 5 * TILE_SIZE, 5 * TILE_SIZE
                
                if current_wave == 10:
                    enemy_max_hp = 600          
                    enemy_hp = enemy_max_hp
                    enemy_speed = 2.0           
                    enemy_damage = 3            
                    try:
                        boss_sound = pygame.mixer.Sound("growl.wav")
                        boss_sound.play()
                    except:
                        print("Файл growl.wav не найден!")
                else:
                    enemy_base_speed = 2.5      
                    enemy_max_hp = 100 + (current_wave - 1) * 20
                    enemy_hp = enemy_max_hp
                    enemy_speed = min(4.5, enemy_base_speed + (current_wave - 1) * 0.2)
                    enemy_damage = 1

    # --- ОТРИСОВКА В ЗАВИСИМОСТИ ОТ СОСТОЯНИЯ ИГРЫ ---
    if game_state == "MENU":
        # Рисуем стильный темный фон меню
        screen.fill((15, 10, 10))
        
        # Заголовок игры
        title_text = font.render("DOOM ARENA 1.1", True, (255, 0, 0))
        screen.blit(title_text, (SCREEN_WIDTH // 2 - 150, SCREEN_HEIGHT // 4))
        
        # Пункты меню
        options = ["PLAY GAME", "SETTINGS", "EXIT"]
        for i, option in enumerate(options):
            if i == menu_selection:
                text_color = (255, 200, 0)
                display_string = f"> {option} <"
            else:
                text_color = (150, 150, 150)
                display_string = option
                
            menu_text = small_font.render(display_string, True, text_color)
            screen.blit(menu_text, (SCREEN_WIDTH // 2 - 80, SCREEN_HEIGHT // 2 + i * 50))
            
    elif game_state == "PLAYING":
        # --- ОПТИМИЗИРОВАННЫЙ РЕНДЕРИНГ МИРА ---
        pygame.draw.rect(screen, (15, 15, 20), (0, 0, SCREEN_WIDTH, SCREEN_HEIGHT // 2))
        pygame.draw.rect(screen, (30, 25, 25), (0, SCREEN_HEIGHT // 2, SCREEN_WIDTH, SCREEN_HEIGHT // 2))

        ray_depths = []

        # Оптимизация: Шаг луча изменен с 1 на 4, чтобы убрать лаги стен!
        start_angle = player_angle - HALF_FOV
        for ray in range(NUM_RAYS):
            sin_r = math.sin(start_angle)
            cos_r = math.cos(start_angle)
            for depth in range(1, MAX_DEPTH, 4): 
                target_x = player_x + depth * cos_r
                target_y = player_y + depth * sin_r
                col, row = int(target_x // TILE_SIZE), int(target_y // TILE_SIZE)
                
                if MAP[row][col] == 1:
                    x_offset = int(target_x) % TILE_SIZE
                    y_offset = int(target_y) % TILE_SIZE
                    texture_offset = x_offset if abs(x_offset - TILE_SIZE/2) > abs(y_offset - TILE_SIZE/2) else y_offset

                    depth *= math.cos(player_angle - start_angle)
                    ray_depths.append(depth)
                    proj_height = min(SCREEN_HEIGHT, (TILE_SIZE * SCREEN_HEIGHT) / (depth + 0.0001))
                    
                    wall_column = wall_texture.subsurface(texture_offset, 0, 1, TILE_SIZE)
                    wall_column = pygame.transform.scale(wall_column, (SCALE, int(proj_height)))
                    screen.blit(wall_column, (ray * SCALE, SCREEN_HEIGHT // 2 - proj_height // 2))
                    break
            else:
                ray_depths.append(MAX_DEPTH)
            start_angle += DELTA_ANGLE

        # --- ОТРИСОВКА ВРАГА ---
        enemy_in_crosshair = False
        if enemy_alive:
            dx = enemy_x - player_x
            dy = enemy_y - player_y
            sprite_dist = math.sqrt(dx**2 + dy**2)

            # ЖЕСТКАЯ ПРОВЕРКА НА УПОР: Если некстбот вплотную, принудительно ставим его по центру экрана!
            if sprite_dist < 25:
                sprite_dist = 25
                sprite_screen_x = SCREEN_WIDTH // 2
                sprite_angle = 0
            else:
                sprite_angle = math.atan2(dy, dx) - player_angle
                if sprite_angle < -math.pi: sprite_angle += 2 * math.pi
                if sprite_angle > math.pi: sprite_angle -= 2 * math.pi
                sprite_screen_x = int((SCREEN_WIDTH // 2) + math.tan(sprite_angle) * (SCREEN_WIDTH // 2))

            # Рендерим спрайт, если он попадает в поле зрения
            if sprite_dist == 25 or (-HALF_FOV - 0.2 < sprite_angle < HALF_FOV + 0.2):
                size_multiplier = 1.8 if current_wave == 10 else 1.0
                sprite_size = int(min(SCREEN_HEIGHT, int((TILE_SIZE * SCREEN_HEIGHT) / sprite_dist)) * size_multiplier)
                
                ray_index = int(sprite_screen_x // SCALE)
                # Отрисовка срабатывает всегда, если враг вплотную (ray_index за границами нам не страшен)
                if sprite_dist == 25 or (0 <= ray_index < NUM_RAYS and ray_depths[ray_index] > sprite_dist):
                    scaled_enemy = pygame.transform.scale(enemy_texture, (sprite_size, sprite_size))
                    
                    if current_wave == 10:
                        color_surface = pygame.Surface(scaled_enemy.get_size()).convert_alpha()
                        color_surface.fill((255, 0, 0, 120)) 
                        scaled_enemy.blit(color_surface, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
                    
                    screen.blit(scaled_enemy, (sprite_screen_x - sprite_size // 2, SCREEN_HEIGHT // 2 - sprite_size // 2))
                    
                    # ХП-Бар над головой некстбота
                    bar_width = sprite_size // 1.5
                    bar_height = max(4, sprite_size // 20)
                    bar_x = sprite_screen_x - bar_width // 2
                    bar_y = SCREEN_HEIGHT // 2 - sprite_size // 2 - bar_height - 10
                    
                    pygame.draw.rect(screen, (200, 0, 0), (bar_x, bar_y, bar_width, bar_height))
                    hp_width = int(bar_width * (enemy_hp / enemy_max_hp))
                    pygame.draw.rect(screen, (0, 200, 0), (bar_x, bar_y, hp_width, bar_height))

                    if abs(sprite_screen_x - SCREEN_WIDTH // 2) < sprite_size // 3:
                        enemy_in_crosshair = True

            if shooting and shoot_frame == 1 and enemy_in_crosshair:
                enemy_hp -= weapon_damage
                if enemy_hp <= 0:
                    enemy_alive = False

                    # --- ОТРИСОВКА АПТЕЧКИ НА АРЕНЕ ---
        if medkit_spawned:
            m_dx = medkit_x - player_x
            m_dy = medkit_y - player_y
            m_dist = math.sqrt(m_dx**2 + m_dy**2)
            
            m_angle = math.atan2(m_dy, m_dx) - player_angle
            if m_angle < -math.pi: m_angle += 2 * math.pi
            if m_angle > math.pi: m_angle -= 2 * math.pi
            
            if -HALF_FOV < m_angle < HALF_FOV and m_dist > 5:
                m_screen_x = int((SCREEN_WIDTH // 2) + math.tan(m_angle) * (SCREEN_WIDTH // 2))
                m_size = int(min(SCREEN_HEIGHT, int((TILE_SIZE * SCREEN_HEIGHT) / m_dist)) * 0.5) # Делаем её поменьше
                
                m_ray_index = int(m_screen_x // SCALE)
                if 0 <= m_ray_index < NUM_RAYS and ray_depths[m_ray_index] > m_dist:
                    scaled_medkit = pygame.transform.scale(medkit_texture, (m_size, m_size))
                    screen.blit(scaled_medkit, (m_screen_x - m_size // 2, SCREEN_HEIGHT // 2 + m_size // 4))

        # --- ОТРИСОВКА ОРУЖИЯ ---
        gun_x = SCREEN_WIDTH // 2 - 175
        gun_y = SCREEN_HEIGHT - 350
        if shooting:
            shoot_frame += 1
            if shoot_frame <= 3: gun_y += 25
            elif shoot_frame <= 6: gun_y -= 25
            else: shooting = False; shoot_frame = 0
            
        if current_weapon == 1:
            screen.blit(gun_texture, (gun_x, gun_y))
        elif current_weapon == 2:
            screen.blit(gun2_texture, (gun_x, gun_y))

        # --- ИНТЕРФЕЙС И ХП ---
        pygame.draw.circle(screen, (255, 0, 0), (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2), 4)

        pygame.draw.rect(screen, (10, 10, 10), (0, SCREEN_HEIGHT - 80, SCREEN_WIDTH, 80))
        pygame.draw.line(screen, (150, 0, 0), (0, SCREEN_HEIGHT - 80), (SCREEN_WIDTH, SCREEN_HEIGHT - 80), 3)

        hp_text = font.render(f"HEALTH: {player_hp}%", True, (255, 0, 0) if player_hp > 30 else (255, 50, 50))
        screen.blit(hp_text, (50, SCREEN_HEIGHT - 65))

        if current_wave == 10:
            wave_text = font.render("WAVE: BOSS INCOMING!", True, (255, 0, 0))
        else:
            wave_text = font.render(f"WAVE: {current_wave}", True, (255, 200, 0))
        screen.blit(wave_text, (SCREEN_WIDTH - 350, SCREEN_HEIGHT - 65))

        if not enemy_alive and not game_over:
            alert_text = font.render("WAVE CLEARED! PREPARING NEXT...", True, (0, 255, 0))
            screen.blit(alert_text, (SCREEN_WIDTH // 2 - 250, SCREEN_HEIGHT // 3))

        # --- СЧЕТЧИК ФПС В ПРАВОМ ВЕРХНЕМ УГЛУ ---
        fps_text = small_font.render(f"FPS: {int(clock.get_fps())}", True, (0, 255, 0))
        screen.blit(fps_text, (SCREEN_WIDTH - 120, 20))

        # --- ТАЙМЕР АПТЕЧКИ ВОЗЛЕ FPS ---
        if player_hp < 50 and not medkit_spawned:
            # Считаем секунды (300 кадров всего, каждые 60 кадров = 1 секунда)
            seconds_left = max(0, 5 - (medkit_timer // 60))
            med_timer_text = small_font.render(f"MEDKIT IN: {seconds_left}s", True, (255, 100, 100))
            screen.blit(med_timer_text, (SCREEN_WIDTH - 160, 50)) # Рисуем чуть ниже FPS

        if game_over:
            pygame.draw.rect(screen, (20, 0, 0), (0, 0, SCREEN_WIDTH, SCREEN_HEIGHT))
            go_text = font.render("YOU DIED", True, (255, 0, 0))
            stat_text = small_font.render(f"You survived up to wave {current_wave}", True, (200, 200, 200))
            
            # Изменили подсказку для игрока
            restart_text = small_font.render("Press ENTER to Restart or ESC for Menu", True, (255, 255, 255))
            
            screen.blit(go_text, (SCREEN_WIDTH // 2 - 80, SCREEN_HEIGHT // 2 - 50))
            screen.blit(stat_text, (SCREEN_WIDTH // 2 - 110, SCREEN_HEIGHT // 2 + 10))
            screen.blit(restart_text, (SCREEN_WIDTH // 2 - 180, SCREEN_HEIGHT // 2 + 50))

            # Логика перезапуска прямо на экране смерти
            keys = pygame.key.get_pressed()
            if keys[pygame.K_RETURN]: # Нажали ENTER — ПОЛНЫЙ СБРОС ИГРЫ
                player_hp = 100
                current_wave = 1
                wave_timer = 0
                enemy_alive = True
                enemy_hp = 100
                enemy_max_hp = 100
                enemy_x, enemy_y = 5 * TILE_SIZE, 5 * TILE_SIZE
                game_over = False
                game_state = "PLAYING"
            elif keys[pygame.K_ESCAPE]: # Нажали ESC — уходим в Главное Меню
                game_over = False
                game_state = "MENU"
                
    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
