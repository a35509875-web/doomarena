import pygame
import math
import os
import random

# Автоматически переключаем рабочую папку туда, где лежит этот файл
try:
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)
except:
    pass

# Инициализация Pygame
pygame.init()
pygame.mixer.init()

# Константы экрана и графики
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60

# Настройки рейкастинга
FOV = math.pi / 3
HALF_FOV = FOV / 2
NUM_RAYS = 120
MAX_DEPTH = 800
DELTA_ANGLE = FOV / NUM_RAYS
SCALE = SCREEN_WIDTH // NUM_RAYS

# Настройки игрока
player_x = 200
player_y = 200
player_angle = 0
player_speed = 3
mouse_sensitivity = 0.002
player_hp = 100

# Геймплейные настройки
current_wave = 1
sound_volume = 0.5
weapon_damage = 35
current_weapon = 1 # 1 - Дробовик, 2 - Пулемет
shooting = False
shoot_frame = 0
shotgun_cooldown = 0       
damage_cooldown = 0

# Размер одной клетки
TILE_SIZE = 50

# Шрифты
font = pygame.font.SysFont('Arial', 36, bold=True)
small_font = pygame.font.SysFont('Arial', 24, bold=True)

# Создание окна (Надежный Фуллскрин)
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN)
pygame.display.set_caption("Doom Arena 1.2")
clock = pygame.time.Clock()
pygame.mouse.set_visible(False)

# --- ПУЛ КАРТ (ОТКРЫТЫЕ АРЕНЫ БЕЗ ЛАБИРИНТОВ) ---
MAPS_POOL = [
    # 1. Большая Арена
    [[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
     [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
     [1,0,1,0,0,0,0,0,0,0,0,0,0,1,0,1],
     [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
     [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
     [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
     [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
     [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
     [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
     [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
     [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
     [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
     [1,0,1,0,0,0,0,0,0,0,0,0,0,1,0,1],
     [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
     [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
     [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]],
    
    # 2. Средняя Арена
    [[1,1,1,1,1,1,1,1,1,1,1,1],
     [1,0,0,0,0,0,0,0,0,0,0,1],
     [1,0,1,0,0,0,0,0,0,1,0,1],
     [1,0,0,0,0,0,0,0,0,0,0,1],
     [1,0,0,0,0,0,0,0,0,0,0,1],
     [1,0,0,0,0,0,0,0,0,0,0,1],
     [1,0,0,0,0,0,0,0,0,0,0,1],
     [1,0,1,0,0,0,0,0,0,1,0,1],
     [1,0,0,0,0,0,0,0,0,0,0,1],
     [1,1,1,1,1,1,1,1,1,1,1,1]],

    # 3. Маленькая Арена
    [[1,1,1,1,1,1,1,1],
     [1,0,0,0,0,0,0,1],
     [1,0,1,0,0,1,0,1],
     [1,0,0,0,0,0,0,1],
     [1,0,0,0,0,0,0,1],
     [1,0,1,0,0,1,0,1],
     [1,0,0,0,0,0,0,1],
     [1,1,1,1,1,1,1,1]]
]

selected_map_index = 1
MAP = MAPS_POOL[selected_map_index]

# --- БЕЗОПАСНАЯ ЗАГРУЗКА ТЕКСТУР ---
wall_texture = pygame.Surface((TILE_SIZE, TILE_SIZE)); wall_texture.fill((70, 70, 80))
gun_texture = pygame.Surface((10, 10)); gun2_texture = pygame.Surface((10, 10))
medkit_texture = pygame.Surface((TILE_SIZE, TILE_SIZE)); medkit_texture.fill((0, 255, 0))
shoot_sound = None

enemy_textures = {1: pygame.Surface((TILE_SIZE, TILE_SIZE)), 2: pygame.Surface((TILE_SIZE, TILE_SIZE)),
                  3: pygame.Surface((TILE_SIZE, TILE_SIZE)), 4: pygame.Surface((TILE_SIZE, TILE_SIZE))}
enemy_textures[1].fill((255, 0, 0)); enemy_textures[2].fill((200, 50, 0))
enemy_textures[3].fill((150, 0, 150)); enemy_textures[4].fill((0, 0, 255))

try:
    wall_texture = pygame.image.load("wall.png").convert()
    wall_texture = pygame.transform.scale(wall_texture, (TILE_SIZE, TILE_SIZE))
except: pass

try: enemy_textures[1] = pygame.image.load("killer.png").convert_alpha()
except: pass
try: enemy_textures[2] = pygame.image.load("killer2.png").convert_alpha()
except: pass
try: enemy_textures[3] = pygame.image.load("killer3.png").convert_alpha()
except: pass
try: enemy_textures[4] = pygame.image.load("killer4.png").convert_alpha()
except: pass

# Делаем пушки нормального, компактного размера (220х220 вместо огромных 350х350)
try:
    gun_texture = pygame.image.load("gun.png").convert_alpha()
    gun_texture = pygame.transform.scale(gun_texture, (220, 220))
except:
    gun_texture = pygame.Surface((40, 100), pygame.SRCALPHA); pygame.draw.rect(gun_texture, (50, 50, 50), (10, 0, 20, 100))

try:
    gun2_texture = pygame.image.load("gun2.png").convert_alpha()
    gun2_texture = pygame.transform.scale(gun2_texture, (220, 220))
except:
    gun2_texture = pygame.Surface((50, 90), pygame.SRCALPHA); pygame.draw.rect(gun2_texture, (80, 80, 90), (10, 0, 30, 90))

try:
    medkit_texture = pygame.image.load("hill.png").convert_alpha()
    medkit_texture = pygame.transform.scale(medkit_texture, (TILE_SIZE, TILE_SIZE))
except: pass

try: shoot_sound = pygame.mixer.Sound("shot.wav")
except: pass

# Эффекты и Таймеры
walk_timer = 0
flash_timer = 0
damage_overlay_timer = 0
blood_particles = [] 
medkit_spawned = False
medkit_timer = 0
medkit_x, medkit_y = 0, 0

# Менеджер волн монстров
enemies = [] # Список живых монстров на арене

def spawn_wave(wave_num):
    global medkit_spawned, medkit_timer
    enemies.clear()
    medkit_spawned = False
    medkit_timer = 0
    
    # Каждый 5-я волна — БОСС
    if wave_num % 5 == 0:
        is_boss = True
        count = 1
    else:
        is_boss = False
        count = max(3, 2 + wave_num) # Минимум 3 монстра, дальше больше
        
    for _ in range(count):
        while True:
            rx = random.randint(1, len(MAP[0]) - 2)
            ry = random.randint(1, len(MAP) - 2)
            if MAP[ry][rx] == 0 and math.sqrt((rx*TILE_SIZE - player_x)**2 + (ry*TILE_SIZE - player_y)**2) > 150:
                e_type = random.choice([1, 2, 3, 4])
                hp = (100 + wave_num * 15) if not is_boss else (400 + wave_num * 50)
                speed = 1.0 + (wave_num * 0.05) if not is_boss else 1.8
                size_multiplier = 1.0 if not is_boss else 2.0 # Босс в 2 раза больше!
                
                enemies.append({
                    'x': rx * TILE_SIZE + TILE_SIZE//2,
                    'y': ry * TILE_SIZE + TILE_SIZE//2,
                    'type': e_type,
                    'hp': hp,
                    'max_hp': hp,
                    'speed': speed,
                    'is_boss': is_boss,
                    'size': size_multiplier
                })
                break

# Состояние игры
game_state = "MENU"
menu_selection = 0
running = True
game_over = False

spawn_wave(current_wave)
pygame.mouse.get_rel()

# ========================================================
# --- ИГРОВОЙ ЦИКЛ ---
# ========================================================
while running:
    if shotgun_cooldown > 0: shotgun_cooldown -= 1
    if damage_cooldown > 0: damage_cooldown -= 1

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
        # Логика Меню
        if game_state == "MENU":
            if event.type == pygame.KEYDOWN:
                if event.key in [pygame.K_UP, pygame.K_w]: menu_selection = (menu_selection - 1) % 3
                if event.key in [pygame.K_DOWN, pygame.K_s]: menu_selection = (menu_selection + 1) % 3
                if event.key == pygame.K_RETURN:
                    if menu_selection == 0: game_state = "SELECT_MAP"; menu_selection = 0
                    elif menu_selection == 1: game_state = "SETTINGS"; menu_selection = 0
                    elif menu_selection == 2: running = False
                        
        elif game_state == "SELECT_MAP":
            if event.type == pygame.KEYDOWN:
                if event.key in [pygame.K_UP, pygame.K_w]: menu_selection = (menu_selection - 1) % 3
                if event.key in [pygame.K_DOWN, pygame.K_s]: menu_selection = (menu_selection + 1) % 3
                if event.key == pygame.K_ESCAPE: game_state = "MENU"
                if event.key == pygame.K_RETURN:
                    selected_map_index = menu_selection
                    MAP = MAPS_POOL[selected_map_index]
                    player_x, player_y = 75, 75
                    player_hp = 100
                    current_wave = 1
                    spawn_wave(current_wave)
                    game_over = False
                    game_state = "PLAYING"
                    pygame.mouse.get_rel()

        elif game_state == "SETTINGS":
            if event.type == pygame.KEYDOWN:
                if event.key in [pygame.K_ESCAPE, pygame.K_RETURN]: game_state = "MENU"
                if event.key in [pygame.K_LEFT, pygame.K_a]: sound_volume = max(0.0, sound_volume - 0.1)
                if event.key in [pygame.K_RIGHT, pygame.K_d]: sound_volume = min(1.0, sound_volume + 0.1)

        elif game_state == "PLAYING":
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE: game_state = "MENU"
                if event.key == pygame.K_1 and not game_over: current_weapon = 1
                if event.key == pygame.K_2 and not game_over: current_weapon = 2

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and not game_over:
                if current_weapon == 1 and not shooting and shotgun_cooldown == 0:
                    shooting = True
                    shoot_frame = 0
                    flash_timer = 5
                    shotgun_cooldown = 35 
                    if shoot_sound: shoot_sound.set_volume(sound_volume); shoot_sound.play()

    # --- ЛОГИКА ГЕЙМПЛЕЯ ---
    if game_state == "PLAYING" and not game_over:
        # Автоматическая стрельба пулемета
        mouse_buttons = pygame.mouse.get_pressed()
        if mouse_buttons[0] and current_weapon == 2 and not shooting:
            shooting = True
            shoot_frame = 0
            flash_timer = 3
            if shoot_sound: shoot_sound.set_volume(sound_volume); shoot_sound.play()

        # Таймер аптечки (начинает тикать ТОЛЬКО при HP < 50%)
        if player_hp < 50 and not medkit_spawned:
            medkit_timer += 1
            if medkit_timer >= 300: # 5 секунд при 60 FPS
                # Спавним аптечку в центре пустой клетки неподалеку
                while True:
                    rx = random.randint(1, len(MAP[0]) - 2)
                    ry = random.randint(1, len(MAP) - 2)
                    if MAP[ry][rx] == 0:
                        medkit_x, medkit_y = rx * TILE_SIZE + TILE_SIZE//2, ry * TILE_SIZE + TILE_SIZE//2
                        medkit_spawned = True
                        break
        elif player_hp >= 50:
            medkit_timer = 0

        # Подбор аптечки
        if medkit_spawned:
            if math.sqrt((medkit_x - player_x)**2 + (medkit_y - player_y)**2) < 25:
                player_hp = min(100, player_hp + 40)
                medkit_spawned = False
                medkit_timer = 0

        # Обзор мышью
        mouse_rel = pygame.mouse.get_rel()
        player_angle += mouse_rel[0] * mouse_sensitivity
        pygame.mouse.set_pos([SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2])

        # Движение
        keys = pygame.key.get_pressed()
        cos_a, sin_a = math.cos(player_angle), math.sin(player_angle)
        move_x, move_y = 0, 0
        if keys[pygame.K_w]: move_x += cos_a; move_y += sin_a
        if keys[pygame.K_s]: move_x -= cos_a; move_y -= sin_a
        if keys[pygame.K_a]: move_x += sin_a; move_y -= cos_a
        if keys[pygame.K_d]: move_x -= sin_a; move_y += cos_a

        dist = math.sqrt(move_x**2 + move_y**2)
        if dist > 0:
            move_x = (move_x / dist) * player_speed
            move_y = (move_y / dist) * player_speed
            walk_timer += 0.2
        else: walk_timer = 0

        new_x, new_y = player_x + move_x, player_y + move_y
        if MAP[int(player_y // TILE_SIZE)][int(new_x // TILE_SIZE)] == 0: player_x = new_x
        if MAP[int(new_y // TILE_SIZE)][int(player_x // TILE_SIZE)] == 0: player_y = new_y

        # Движение ВСЕХ монстров в толпе
        for e in enemies:
            edx, edy = player_x - e['x'], player_y - e['y']
            edist = math.sqrt(edx**2 + edy**2)
            if edist > 15:
                e['x'] += (edx / edist) * e['speed']
                e['y'] += (edy / edist) * e['speed']
            
            # Нанесение урона игроку
            if edist < 25 and damage_cooldown == 0:
                dmg = 10 if not e['is_boss'] else 25
                player_hp = max(0, player_hp - dmg)
                damage_overlay_timer = 8
                damage_cooldown = 25
                if player_hp <= 0: game_over = True

        # Проверка смерти волны
        if len(enemies) == 0:
            current_wave += 1
            spawn_wave(current_wave)

        # Движение частиц крови
        for p in blood_particles[:]:
            p[0] += p[2]; p[1] += p[3]; p[5] -= 1
            if p[5] <= 0: blood_particles.remove(p)

    # --- РЕНДЕРИНГ ЭКРАНОВ ---
    if game_state == "MENU":
        screen.fill((15, 10, 10))
        title_text = font.render("DOOM ARENA 1.2", True, (255, 0, 0))
        screen.blit(title_text, (SCREEN_WIDTH // 2 - 140, SCREEN_HEIGHT // 4))
        options = ["START GAME", "SETTINGS", "EXIT"]
        for i, option in enumerate(options):
            color = (255, 200, 0) if i == menu_selection else (150, 150, 150)
            text = small_font.render(f"> {option} <" if i == menu_selection else option, True, color)
            screen.blit(text, (SCREEN_WIDTH // 2 - 70, SCREEN_HEIGHT // 2 + i * 45))

    elif game_state == "SELECT_MAP":
        screen.fill((10, 15, 10))
        title_text = font.render("CHOOSE ARENA", True, (0, 255, 0))
        screen.blit(title_text, (SCREEN_WIDTH // 2 - 130, SCREEN_HEIGHT // 4))
        options = ["1. LARGE ARENA", "2. MEDIUM ARENA", "3. SMALL PIT"]
        for i, option in enumerate(options):
            color = (0, 255, 0) if i == menu_selection else (100, 150, 100)
            text = small_font.render(f"> {option} <" if i == menu_selection else option, True, color)
            screen.blit(text, (SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 + i * 45))

    elif game_state == "SETTINGS":
        screen.fill((10, 10, 20))
        title_text = font.render("SOUND SETTINGS", True, (0, 100, 255))
        screen.blit(title_text, (SCREEN_WIDTH // 2 - 140, SCREEN_HEIGHT // 4))
        vol_text = small_font.render(f"VOLUME: {int(sound_volume * 100)}% (A / D to change)", True, (200, 200, 255))
        back_text = small_font.render("Press ESC to go Back", True, (150, 150, 150))
        screen.blit(vol_text, (SCREEN_WIDTH // 2 - 170, SCREEN_HEIGHT // 2))
        screen.blit(back_text, (SCREEN_WIDTH // 2 - 110, SCREEN_HEIGHT // 2 + 60))

    elif game_state == "PLAYING":
        # Небо и пол
        pygame.draw.rect(screen, (20, 20, 25), (0, 0, SCREEN_WIDTH, SCREEN_HEIGHT // 2))
        pygame.draw.rect(screen, (35, 30, 30), (0, SCREEN_HEIGHT // 2, SCREEN_WIDTH, SCREEN_HEIGHT // 2))
        
        # 3D Стены (Рейкастинг)
        ray_depths = []
        start_angle = player_angle - HALF_FOV
        for ray in range(NUM_RAYS):
            sin_r, cos_r = math.sin(start_angle), math.cos(start_angle)
            for depth in range(1, MAX_DEPTH, 5):
                tx = player_x + depth * cos_r
                ty = player_y + depth * sin_r
                if MAP[int(ty // TILE_SIZE)][int(tx // TILE_SIZE)] == 1:
                    texture_offset = int(tx) % TILE_SIZE if abs(int(tx)%TILE_SIZE - TILE_SIZE/2) > abs(int(ty)%TILE_SIZE - TILE_SIZE/2) else int(ty) % TILE_SIZE
                    depth *= math.cos(player_angle - start_angle)
                    ray_depths.append(depth)
                    proj_height = min(SCREEN_HEIGHT, (TILE_SIZE * SCREEN_HEIGHT) / (depth + 0.0001))
                    try:
                        w_col = wall_texture.subsurface(texture_offset, 0, 1, TILE_SIZE)
                        w_col = pygame.transform.scale(w_col, (SCALE, int(proj_height)))
                        screen.blit(w_col, (ray * SCALE, SCREEN_HEIGHT // 2 - proj_height // 2))
                    except:
                        pygame.draw.rect(screen, (80, 80, 90), (ray * SCALE, SCREEN_HEIGHT // 2 - proj_height // 2, SCALE, proj_height))
                    break
            else: ray_depths.append(MAX_DEPTH)
            start_angle += DELTA_ANGLE

        # Отрисовка аптечки в 3D окружении
        if medkit_spawned:
            mdx, mdy = medkit_x - player_x, medkit_y - player_y
            mdist = math.sqrt(mdx**2 + mdy**2)
            ma = math.atan2(mdy, mdx) - player_angle
            if ma < -math.pi: ma += 2 * math.pi
            if ma > math.pi: ma -= 2 * math.pi
            if -HALF_FOV < ma < HALF_FOV:
                sx = int((SCREEN_WIDTH // 2) + math.tan(ma) * (SCREEN_WIDTH // 2))
                sz = int(min(SCREEN_HEIGHT, int((TILE_SIZE * SCREEN_HEIGHT) / (mdist + 0.001))) * 0.4)
                r_idx = int(sx // SCALE)
                if 0 <= r_idx < NUM_RAYS and ray_depths[r_idx] > mdist:
                    try:
                        scaled_med = pygame.transform.scale(medkit_texture, (sz, sz))
                        screen.blit(scaled_med, (sx - sz // 2, SCREEN_HEIGHT // 2 + sz // 4))
                    except: pass

        # Отрисовка ВСЕХ монстров (Сортировка по дальности, чтобы дальние не перекрывали ближних)
        enemies.sort(key=lambda e: (e['x'] - player_x)**2 + (e['y'] - player_y)**2, reverse=True)
        
        enemy_in_crosshair = False
        target_enemy = None

        for e in enemies:
            dx, dy = e['x'] - player_x, e['y'] - player_y
            sprite_dist = math.sqrt(dx**2 + dy**2)
            
            sa = math.atan2(dy, dx) - player_angle
            if sa < -math.pi: sa += 2 * math.pi
            if sa > math.pi: sa -= 2 * math.pi
            s_x = int((SCREEN_WIDTH // 2) + math.tan(sa) * (SCREEN_WIDTH // 2))

            if -HALF_FOV - 0.3 < sa < HALF_FOV + 0.3:
                s_size = int(min(SCREEN_HEIGHT, int((TILE_SIZE * SCREEN_HEIGHT) / (sprite_dist + 0.001))) * e['size'])
                r_idx = int(s_x // SCALE)
                if 0 <= r_idx < NUM_RAYS and ray_depths[r_idx] > sprite_dist:
                    try:
                        tex = enemy_textures.get(e['type'], enemy_textures[1])
                        scaled_enemy = pygame.transform.scale(tex, (s_size, s_size))
                        # Если босс, слегка подкрашиваем в фиолетовый
                        if e['is_boss']:
                            scaled_enemy.fill((50, 0, 50, 0), special_flags=pygame.BLEND_RGBA_ADD)
                        screen.blit(scaled_enemy, (s_x - s_size // 2, SCREEN_HEIGHT // 2 - s_size // 2))
                    except:
                        pygame.draw.rect(screen, (255, 0, 0), (s_x - s_size // 2, SCREEN_HEIGHT // 2 - s_size // 2, s_size, s_size))

                    # ХП бар монстра
                    bw, bh = s_size // 1.2, max(4, s_size // 18)
                    bx, by = s_x - bw // 2, SCREEN_HEIGHT // 2 - s_size // 2 - bh - 5
                    pygame.draw.rect(screen, (150,0,0), (bx, by, bw, bh))
                    pygame.draw.rect(screen, (0,200,0), (bx, by, int(bw * (e['hp'] / e['max_hp'])), bh))
                    
                    # Проверяем наводку прицела (выбираем ближайшего по центру)
                    if abs(s_x - SCREEN_WIDTH // 2) < s_size // 3:
                        enemy_in_crosshair = True
                        target_enemy = e

        # Обработка попадания при стрельбе
        if shooting and shoot_frame == 1 and enemy_in_crosshair and target_enemy:
            dmg = weapon_damage if current_weapon == 1 else weapon_damage // 2
            target_enemy['hp'] -= dmg
            for _ in range(10):
                blood_particles.append([SCREEN_WIDTH//2 + random.randint(-15,15), SCREEN_HEIGHT//2 + random.randint(-15,15), random.uniform(-3,3), random.uniform(-3,3), (160, 0, 0), random.randint(15,30)])
            if target_enemy['hp'] <= 0:
                enemies.remove(target_enemy)

        # Отрисовка частиц крови
        for p in blood_particles:
            pygame.draw.rect(screen, p[4], (p[0], p[1], 5, 5))

        # Оружие в руках (Компактный размер)
        gun_bob_x = int(math.sin(walk_timer) * 10) if not game_over else 0
        gun_bob_y = int(abs(math.cos(walk_timer)) * 10) if not game_over else 0
        gun_x = SCREEN_WIDTH // 2 - (gun_texture.get_width() // 2) + gun_bob_x
        gun_y = SCREEN_HEIGHT - gun_texture.get_height() + gun_bob_y + 10 # Сдвинуто вниз

        if shooting:
            shoot_frame += 1
            if shoot_frame <= 3: gun_y += 15
            elif shoot_frame <= 6: gun_y -= 15
            else: shooting = False; shoot_frame = 0

        if not game_over:
            if current_weapon == 1: screen.blit(gun_texture, (gun_x, gun_y))
            elif current_weapon == 2: screen.blit(gun2_texture, (gun_x, gun_y))

        # Эффекты вспышек
        if flash_timer > 0:
            flash_timer -= 1
            pygame.draw.circle(screen, (255, 230, 150), (SCREEN_WIDTH // 2, gun_y + 10), random.randint(20, 30))

        if damage_overlay_timer > 0:
            damage_overlay_timer -= 1
            blood_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            pygame.draw.rect(blood_surf, (180, 0, 0, 70), (0, 0, SCREEN_WIDTH, SCREEN_HEIGHT), 15)
            screen.blit(blood_surf, (0, 0))

        # Панель интерфейса (HUD)
        pygame.draw.circle(screen, (255, 0, 0), (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2), 3, 1) # Прицел
        pygame.draw.rect(screen, (10, 10, 10), (0, SCREEN_HEIGHT - 60, SCREEN_WIDTH, 60))
        
        hp_text = font.render(f"HEALTH: {int(player_hp)}%", True, (255, 0, 0))
        screen.blit(hp_text, (30, SCREEN_HEIGHT - 48))
        
        # Сведения о волне
        is_boss_wave = current_wave % 5 == 0
        wave_str = f"WAVE: {current_wave} (BOSS)" if is_boss_wave else f"WAVE: {current_wave} | ENEMIES: {len(enemies)}"
        wave_text = font.render(wave_str, True, (255, 200, 0) if not is_boss_wave else (200, 0, 255))
        screen.blit(wave_text, (280, SCREEN_HEIGHT - 48))

        # --- СЧЁТЧИКИ НА ЭКРАНЕ (FPS И ТАЙМЕР АПТЕЧКИ) ---
        fps_text = small_font.render(f"FPS: {int(clock.get_fps())}", True, (0, 255, 0))
        screen.blit(fps_text, (SCREEN_WIDTH - 110, 20))
        
        if player_hp < 50 and not medkit_spawned:
            med_seconds = max(0, 5 - (medkit_timer // 60))
            med_timer_text = small_font.render(f"MEDKIT IN: {med_seconds}s", True, (255, 50, 50))
            screen.blit(med_timer_text, (SCREEN_WIDTH - 160, 50))
        elif medkit_spawned:
            med_ready_text = small_font.render("MEDKIT SPAWNED!", True, (0, 255, 0))
            screen.blit(med_ready_text, (SCREEN_WIDTH - 200, 50))

        # Экран смерти
        if game_over:
            go_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            go_surf.fill((30, 0, 0, 200))
            screen.blit(go_surf, (0,0))
            go_text = font.render("YOU DIED", True, (255, 0, 0))
            restart_text = small_font.render("Press ENTER to Restart or ESC to Main Menu", True, (255, 255, 255))
            screen.blit(go_text, (SCREEN_WIDTH // 2 - 75, SCREEN_HEIGHT // 2 - 30))
            screen.blit(restart_text, (SCREEN_WIDTH // 2 - 190, SCREEN_HEIGHT // 2 + 30))
            
            keys = pygame.key.get_pressed()
            if keys[pygame.K_RETURN]:
                player_x, player_y, player_hp, current_wave = 200, 200, 100, 1
                game_over = False
                spawn_wave(current_wave)
                pygame.mouse.get_rel()
            elif keys[pygame.K_ESCAPE]:
                game_over = False
                game_state = "MENU"

    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
